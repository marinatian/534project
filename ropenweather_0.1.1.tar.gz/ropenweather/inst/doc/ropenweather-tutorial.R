## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(ropenweather)

## -----------------------------------------------------------------------------
library(ropenweather)

## -----------------------------------------------------------------------------
api_key <- "f4ae84f3cc4c51353a1ae2279dd7a60b" # Replace with your actual API key

## -----------------------------------------------------------------------------
lat <- 40.7128  # Example latitude for New York City
lon <- -74.0060 # Example longitude for New York City
current_weather <- get_current_weather(lat, lon, api_key)

## -----------------------------------------------------------------------------
forecast_weather <- get_forecast_weather(lat, lon, api_key)

## -----------------------------------------------------------------------------
processed_current <- process_current_weather(current_weather)


## -----------------------------------------------------------------------------
processed_forecast <- process_forecast_weather(forecast_weather)

## -----------------------------------------------------------------------------
visualize_current_weather(processed_current)

## -----------------------------------------------------------------------------
visualize_forecast_weather(processed_forecast)

